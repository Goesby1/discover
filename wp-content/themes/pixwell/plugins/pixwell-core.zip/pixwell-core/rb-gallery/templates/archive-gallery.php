<?php
/**
 * fallback archive template
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
